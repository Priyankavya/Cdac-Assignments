package com.example.SpringBootMVCProductCurd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcProductCurdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcProductCurdApplication.class, args);
	}

}
